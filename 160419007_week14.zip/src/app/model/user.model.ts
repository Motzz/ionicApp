export class UserModel {
  constructor(
    public user_id: string,
    public user_name: string,
    public user_password: string
  ) {}
}
