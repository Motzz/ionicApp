export class movieModel {
  constructor(
    public judul: string,
    public sinopsis: string,
    public poster: string
  ) {}
}
