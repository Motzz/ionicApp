import { Component } from '@angular/core';
import { ProductModel } from './product.model';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
// export class AppComponent {
//   constructor() {}
// }
export class AppComponent {
  username = 'Timothy';
  judul = 'Ionic-Angular week 09';
  katadariapp = 'no.';
  productsPhone: ProductModel[] = [
    new ProductModel('Realme 5', 1800000, 0.1, 'samsung10.jpg', [
      '4 Gb',
      'Snapdragon',
      '128 Gb',
    ]),
    new ProductModel('OPPO A1', 1400000, 0.15, 'samsung10.jpg', [
      '8 Gb',
      'Snapdragon',
      '128 Gb',
    ]),
    new ProductModel('Samsung Galaxy A10', 1200000, 0, 'samsung10.jpg', [
      '7 Gb',
      'Snapdragon',
      '128 Gb',
    ]),
    new ProductModel('Redmi Note 8', 1900000, 0.2, 'samsung10.jpg', [
      '5 Gb',
      'Snapdragon',
      '128 Gb',
    ]),
    new ProductModel('Iphone X', 6300000, 0.25, 'samsung10.jpg', [
      '2 Gb',
      'Snapdragon',
      '128 Gb',
    ]),
  ];
  constructor() {}
}
